package com.example.emuhost.data

import android.content.Context

class VmRepository(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("vms", Context.MODE_PRIVATE)
    fun load(): List<Vm> = prefs.getString("list", null)?.let { runCatching { Vm.listFromJson(it) }.getOrNull() } ?: emptyList()
    fun save(list: List<Vm>) = prefs.edit().putString("list", Vm.listToJson(list)).apply()
}
