package com.example.emuhost.engine

import android.app.*
import android.content.Intent
import android.os.IBinder

/** Keeps the emulator process alive when the app is in the background. */
class VmService : Service() {
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vm", "Running VMs", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "vm")
            .setContentTitle("Virtual machine running")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        startForeground(1, n)
        return START_STICKY
    }
}
