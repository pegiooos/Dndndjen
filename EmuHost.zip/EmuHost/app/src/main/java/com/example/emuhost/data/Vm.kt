package com.example.emuhost.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class GuestType(val label: String) {
    ANDROID("Android (x86)"),
    PC("PC OS (Windows/Linux)")
}

enum class Arch(val label: String, val qemuBinary: String) {
    X86_64("x86_64", "libqemu-system-x86_64.so"),
    I386("i386", "libqemu-system-i386.so"),
    AARCH64("aarch64", "libqemu-system-aarch64.so")
}

enum class Accel(val label: String) { TCG("Software (TCG)"), KVM("KVM (if device allows)") }

/** Android-x86 releases only go up to Android 9 officially; Android 10 builds are unofficial (Bliss/Android-Generic). */
enum class AndroidVersion(val label: String) {
    A4("Android 4.4"), A5("Android 5.1"), A6("Android 6.0"), A7("Android 7.1"),
    A8("Android 8.1"), A9("Android 9.0"), A10("Android 10 (unofficial x86 builds)")
}

data class Vm(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: GuestType,
    val androidVersion: AndroidVersion? = null,
    val arch: Arch = Arch.X86_64,
    val ramMb: Int = 2048,
    val cores: Int = 2,
    val diskUri: String,            // .img / .qcow2 / .iso picked via SAF
    val isCdrom: Boolean = false,   // true when diskUri is an installer ISO
    val newDiskGb: Int = 0,         // >0 => create blank qcow2 and use ISO as installer
    val accel: Accel = Accel.TCG,
    val vncPort: Int = 5901
) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("name", name); put("type", type.name)
        put("av", androidVersion?.name ?: ""); put("arch", arch.name)
        put("ram", ramMb); put("cores", cores); put("disk", diskUri)
        put("cdrom", isCdrom); put("newDisk", newDiskGb)
        put("accel", accel.name); put("vnc", vncPort)
    }
    companion object {
        fun fromJson(o: JSONObject) = Vm(
            id = o.getString("id"), name = o.getString("name"),
            type = GuestType.valueOf(o.getString("type")),
            androidVersion = o.getString("av").takeIf { it.isNotEmpty() }?.let { AndroidVersion.valueOf(it) },
            arch = Arch.valueOf(o.getString("arch")), ramMb = o.getInt("ram"),
            cores = o.getInt("cores"), diskUri = o.getString("disk"),
            isCdrom = o.getBoolean("cdrom"), newDiskGb = o.getInt("newDisk"),
            accel = Accel.valueOf(o.getString("accel")), vncPort = o.getInt("vnc")
        )
        fun listToJson(l: List<Vm>) = JSONArray().also { a -> l.forEach { a.put(it.toJson()) } }.toString()
        fun listFromJson(s: String): List<Vm> {
            val a = JSONArray(s); return (0 until a.length()).map { fromJson(a.getJSONObject(it)) }
        }
    }
}
