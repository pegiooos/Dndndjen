package com.example.emuhost.ui

import android.content.Context
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.emuhost.engine.QemuInstaller
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupScreen(ctx: Context, onDone: () -> Unit, onSkip: () -> Unit) {
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("setup", Context.MODE_PRIVATE) }
    var url by remember { mutableStateOf(prefs.getString("url", "") ?: "") }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var status by remember { mutableStateOf("") }
    var installed by remember { mutableStateOf(QemuInstaller.installedArchs(ctx)) }
    var report by remember { mutableStateOf(QemuInstaller.report(ctx)) }

    fun run(label: String, block: suspend () -> String) {
        scope.launch {
            busy = true; status = label; progress = -1f
            status = try { withContext(Dispatchers.IO) { block() } } catch (e: Throwable) { "Failed: ${e.message}" }
            installed = QemuInstaller.installedArchs(ctx); report = QemuInstaller.report(ctx); busy = false
        }
    }

    val zipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { u ->
            val name = ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (c.moveToFirst() && i >= 0) c.getString(i) else null
            } ?: u.lastPathSegment ?: "archive"
            run("Extracting…") { "Installed ${QemuInstaller.importArchive(ctx, u, name) { s -> status = s }} files" }
        }
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) run("Importing files…") {
            uris.forEach { u ->
                val name = ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (c.moveToFirst() && i >= 0) c.getString(i) else null
                } ?: u.lastPathSegment ?: "file"
                QemuInstaller.importFile(ctx, u, name)
            }
            "Imported ${uris.size} file(s)"
        }
    }

    Scaffold(topBar = { LargeTopAppBar(title = { Text("Set up QEMU") }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("EmuHost needs QEMU (an Android arm64 build) to run virtual machines. Download it, or import files you already have.",
                style = MaterialTheme.typography.bodyLarge)

            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CloudDownload, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(12.dp)); Text("Download online", style = MaterialTheme.typography.titleMedium)
                    }
                    OutlinedTextField(url, { url = it }, label = { Text("URL to archive or binary") },
                        placeholder = { Text("https://…/qemu-android-arm64.zip") }, modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !busy)
                    Button(enabled = !busy && url.startsWith("http"), onClick = {
                        prefs.edit().putString("url", url).apply()
                        run("Downloading…") { QemuInstaller.download(ctx, url.trim()) { p -> progress = p } }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Download and install") }
                }
            }

            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.FolderZip, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(12.dp)); Text("Import yourself", style = MaterialTheme.typography.titleMedium)
                    }
                    Text("Archives (zip, tar.xz, tar.gz, tar.bz2) can contain qemu-system-*, qemu-img and BIOS files in any folder layout, even archives inside archives.", style = MaterialTheme.typography.bodySmall)
                    FilledTonalButton(enabled = !busy, onClick = { zipPicker.launch(arrayOf("*/*")) },
                        modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FolderZip, null); Spacer(Modifier.width(8.dp)); Text("Import archive (zip, tar.xz, tar.gz)") }
                    OutlinedButton(enabled = !busy, onClick = { filePicker.launch(arrayOf("*/*")) },
                        modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FileOpen, null); Spacer(Modifier.width(8.dp)); Text("Import individual files") }
                }
            }

            if (busy) { if (progress in 0f..1f) LinearProgressIndicator({ progress }, Modifier.fillMaxWidth()) else LinearProgressIndicator(Modifier.fillMaxWidth()) }
            if (status.isNotBlank()) Text(status, style = MaterialTheme.typography.bodyMedium)
            if (report.isNotBlank()) Text(report, style = MaterialTheme.typography.bodySmall)

            if (installed.isNotEmpty()) {
                Text("Installed: " + installed.joinToString { it.label }, style = MaterialTheme.typography.titleSmall)
                Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) { Text("Continue") }
                TextButton(onClick = { QemuInstaller.clear(ctx); installed = emptyList(); report = ""; status = "Removed installed files" },
                    modifier = Modifier.fillMaxWidth()) { Text("Remove installed QEMU") }
            } else TextButton(onClick = onSkip, modifier = Modifier.fillMaxWidth()) { Text("Set up later") }
        }
    }
}
