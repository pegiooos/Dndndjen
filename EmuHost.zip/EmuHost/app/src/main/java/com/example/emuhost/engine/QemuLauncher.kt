package com.example.emuhost.engine

import android.content.Context
import android.net.Uri
import com.example.emuhost.data.*
import java.io.File

/**
 * Builds and runs a QEMU command line. QEMU itself is NOT included: you must provide
 * cross-compiled aarch64 Android binaries named libqemu-system-*.so in app/src/main/jniLibs/arm64-v8a/
 * (plus the BIOS/firmware files in assets/qemu-bios -> copied to filesDir/bios on first run).
 * Display is exposed over local VNC (127.0.0.1:5900+n); the app's viewer connects to it.
 */
object QemuLauncher {
    private val running = mutableMapOf<String, Process>()

    fun isRunning(id: String) = running[id]?.isAlive == true

    fun buildArgs(ctx: Context, vm: Vm, diskPath: String, extraDisk: String?): List<String> {
        val bios = QemuInstaller.biosDir(ctx).absolutePath
        val args = mutableListOf<String>()
        args += listOf("-L", bios)
        args += listOf("-m", vm.ramMb.toString())
        args += listOf("-smp", vm.cores.toString())
        args += when (vm.accel) {
            Accel.KVM -> listOf("-accel", "kvm", "-cpu", "host")
            Accel.TCG -> listOf("-accel", "tcg,thread=multi", "-cpu", if (vm.arch == Arch.AARCH64) "cortex-a72" else "qemu64")
        }
        if (vm.arch == Arch.AARCH64) args += listOf("-M", "virt")
        else args += listOf("-M", "pc")

        if (vm.isCdrom) {
            args += listOf("-cdrom", diskPath)
            extraDisk?.let { args += listOf("-drive", "file=$it,if=virtio,format=qcow2"); args += listOf("-boot", "d") }
        } else {
            args += listOf("-drive", "file=$diskPath,if=virtio,cache=writeback")
        }
        // Display + input over VNC, tablet gives absolute pointer so touch maps well
        args += listOf("-vnc", "127.0.0.1:${vm.vncPort - 5900}")
        args += listOf("-device", "virtio-vga")          // use "-vga std" if virtio-vga unsupported
        args += listOf("-device", "usb-ehci", "-device", "usb-tablet", "-device", "usb-kbd")
        args += listOf("-nic", "user,model=virtio-net-pci")
        args += listOf("-audiodev", "none,id=snd0")
        if (vm.type == GuestType.ANDROID) {
            // Android-x86 wants GL-less std VGA + larger video mem on TCG
            args += listOf("-global", "VGA.vgamem_mb=64")
        }
        return args
    }

    /** Copies a SAF uri into app storage (QEMU needs a real file path). Cached by name. */
    fun materialize(ctx: Context, uri: String, name: String): File {
        val out = File(ctx.filesDir, "images/$name").also { it.parentFile?.mkdirs() }
        if (!out.exists()) ctx.contentResolver.openInputStream(Uri.parse(uri))!!.use { i -> out.outputStream().use { i.copyTo(it) } }
        return out
    }

    fun start(ctx: Context, vm: Vm, onLog: (String) -> Unit): Result<Unit> = runCatching {
        val bin = QemuInstaller.findBinary(ctx, vm.arch)
            ?: error("QEMU for ${vm.arch.label} is not installed. Open Set up QEMU (gear icon) to download or import it.\n" + QemuInstaller.report(ctx))
        val disk = materialize(ctx, vm.diskUri, vm.id + (if (vm.isCdrom) ".iso" else ".img"))
        val extra = if (vm.isCdrom && vm.newDiskGb > 0) {
            val q = File(ctx.filesDir, "images/${vm.id}.qcow2")
            if (!q.exists()) {
                val img = QemuInstaller.findTool(ctx, "qemu-img") ?: error("qemu-img not found in installed QEMU files")
                ProcessBuilder(img.absolutePath, "create", "-f", "qcow2", q.absolutePath, "${vm.newDiskGb}G")
                    .redirectErrorStream(true).start().waitFor()
            }
            q.absolutePath
        } else null
        val cmd = listOf(bin.absolutePath) + buildArgs(ctx, vm, disk.absolutePath, extra)
        onLog(cmd.joinToString(" "))
        val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
        running[vm.id] = p
        Thread { p.inputStream.bufferedReader().forEachLine(onLog) }.start()
    }

    fun stop(id: String) { running.remove(id)?.destroy() }
}
