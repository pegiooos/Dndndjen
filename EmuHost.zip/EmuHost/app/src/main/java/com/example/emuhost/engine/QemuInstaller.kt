package com.example.emuhost.engine

import android.content.Context
import android.net.Uri
import android.os.Build
import com.example.emuhost.data.Arch
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Manages QEMU files in filesDir/qemu. Supports zip, tar.xz, tar.gz, tar.bz2, tar (also archives
 * nested inside archives), individual files, and downloading from a URL.
 */
object QemuInstaller {
    fun dir(ctx: Context) = File(ctx.filesDir, "qemu").also { it.mkdirs() }

    // ---------- detection ----------

    /** CPU type from the ELF header: 183 = arm64, 62 = x86_64, 40 = arm32, 3 = x86. Null if not an ELF file. */
    fun elfMachine(f: File): Int? = try {
        f.inputStream().use { s ->
            val h = ByteArray(20)
            if (s.read(h) < 20 || h[0] != 0x7F.toByte() || h[1] != 'E'.code.toByte() ||
                h[2] != 'L'.code.toByte() || h[3] != 'F'.code.toByte()) null
            else (h[18].toInt() and 0xFF) or ((h[19].toInt() and 0xFF) shl 8)
        }
    } catch (e: Exception) { null }

    private fun deviceMachine(): Int {
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: ""
        return when {
            abi.startsWith("arm64") -> 183
            abi == "x86_64" -> 62
            abi.startsWith("armeabi") -> 40
            abi == "x86" -> 3
            else -> 183
        }
    }

    private fun machineName(m: Int?) = when (m) {
        183 -> "arm64"; 62 -> "x86_64"; 40 -> "arm32"; 3 -> "x86"; null -> "not a binary"; else -> "cpu $m"
    }

    private val archTokens = setOf("x86_64", "x86-64", "amd64", "x64", "i386", "i686", "arm64", "aarch64")

    private fun hint(text: String): Arch? {
        val p = text.lowercase()
        return when {
            Regex("aarch64|arm64").containsMatchIn(p) -> Arch.AARCH64
            Regex("x86[_-]64|amd64|x64").containsMatchIn(p) -> Arch.X86_64
            Regex("i386|i686|x86").containsMatchIn(p) -> Arch.I386
            else -> null
        }
    }

    /** QEMU system binaries built for this phone's CPU. Guest arch is guessed from file name, else folder name. */
    fun systemBinaries(ctx: Context): List<Pair<File, Arch>> {
        val root = dir(ctx)
        val want = deviceMachine()
        return root.walkTopDown().filter { it.isFile && elfMachine(it) == want }.mapNotNull { f ->
            val n = f.name.lowercase()
            if (n.contains("qemu-img") || n.contains("qemu-io") || n.contains("qemu-nbd") || n.contains("qemu-edid")) return@mapNotNull null
            if (n.endsWith(".so") && !n.contains("qemu-system")) return@mapNotNull null
            if (!(n.contains("qemu") || n in archTokens)) return@mapNotNull null
            val a = hint(n.removePrefix("lib").removeSuffix(".so"))
                ?: hint(f.parentFile?.relativeTo(root)?.path ?: "")
                ?: return@mapNotNull null
            f to a
        }.toList()
    }

    fun findTool(ctx: Context, name: String): File? {
        val want = deviceMachine()
        dir(ctx).walkTopDown()
            .firstOrNull { it.isFile && it.name.lowercase().contains(name) && elfMachine(it) == want }
            ?.let { return it }
        return File(ctx.applicationInfo.nativeLibraryDir, "lib$name.so").takeIf { it.exists() }
    }

    fun findBinary(ctx: Context, arch: Arch): File? =
        systemBinaries(ctx).firstOrNull { it.second == arch }?.first
            ?: File(ctx.applicationInfo.nativeLibraryDir, arch.qemuBinary).takeIf { it.exists() }

    fun report(ctx: Context): String {
        val root = dir(ctx)
        val files = root.walkTopDown().filter { it.isFile }.toList()
        if (files.isEmpty()) return ""
        val sb = StringBuilder("This phone: ${machineName(deviceMachine())}\n")
        val bins = systemBinaries(ctx)
        if (bins.isNotEmpty()) {
            sb.append("Detected:\n")
            bins.forEach { sb.append("• ${it.first.relativeTo(root).path} → ${it.second.label}\n") }
        } else {
            sb.append("No usable QEMU binary found. ${files.size} files:\n")
            files.take(15).forEach { sb.append("• ${it.relativeTo(root).path}  [${machineName(elfMachine(it))}]\n") }
        }
        return sb.toString().trim()
    }

    fun biosDir(ctx: Context): File =
        dir(ctx).walkTopDown().firstOrNull { it.isFile && it.name == "bios-256k.bin" }?.parentFile ?: dir(ctx)

    fun installedArchs(ctx: Context): List<Arch> = Arch.entries.filter { findBinary(ctx, it) != null }
    fun isInstalled(ctx: Context) = installedArchs(ctx).isNotEmpty()

    fun clear(ctx: Context) { dir(ctx).deleteRecursively(); dir(ctx) }

    // ---------- archives ----------

    private fun finish(f: File) { f.setExecutable(true, false); f.setReadable(true, false) }

    private fun safeOut(root: File, base: File, name: String): File {
        val out = File(base, name).canonicalFile
        if (!out.path.startsWith(root.path + File.separator)) throw SecurityException("Bad archive entry: $name")
        return out
    }

    private fun peek(bin: BufferedInputStream, size: Int): ByteArray {
        bin.mark(size + 8)
        val buf = ByteArray(size)
        var n = 0
        while (n < size) {
            val r = bin.read(buf, n, size - n)
            if (r < 0) break
            n += r
        }
        bin.reset()
        return buf.copyOf(n)
    }

    private fun isTar(h: ByteArray) = h.size >= 262 && String(h, 257, 5, Charsets.ISO_8859_1) == "ustar"

    private fun extractZip(root: File, base: File, input: InputStream, log: (String) -> Unit): Int {
        var count = 0
        ZipInputStream(input).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                val out = safeOut(root, base, e.name)
                if (e.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zis.copyTo(it) }
                    finish(out); count++; log("Extracted ${out.name}")
                }
                zis.closeEntry(); e = zis.nextEntry
            }
        }
        return count
    }

    private fun extractTar(root: File, base: File, input: InputStream, log: (String) -> Unit): Int {
        var count = 0
        TarArchiveInputStream(input).use { tar ->
            var e = tar.nextTarEntry
            while (e != null) {
                if (e.isDirectory) safeOut(root, base, e.name).mkdirs()
                else if (!e.isSymbolicLink && !e.isLink) {
                    val out = safeOut(root, base, e.name)
                    out.parentFile?.mkdirs()
                    out.outputStream().use { tar.copyTo(it) }
                    finish(out); count++; log("Extracted ${out.name}")
                }
                e = tar.nextTarEntry
            }
        }
        return count
    }

    /** A decompressed stream is either a tar (extract it) or one single file (save it under name without the extension). */
    private fun extractCompressed(root: File, base: File, decompressed: InputStream, name: String, log: (String) -> Unit): Int {
        val bin = BufferedInputStream(decompressed, 64 * 1024)
        return if (isTar(peek(bin, 512))) extractTar(root, base, bin, log) else {
            val out = safeOut(root, base, name.substringBeforeLast('.').ifBlank { "qemu-binary" })
            out.parentFile?.mkdirs()
            out.outputStream().use { bin.copyTo(it) }
            finish(out); log("Extracted ${out.name}"); 1
        }
    }

    private fun extractAny(root: File, base: File, input: InputStream, name: String, log: (String) -> Unit): Int {
        val bin = BufferedInputStream(input, 64 * 1024)
        val h = peek(bin, 512)
        fun at(i: Int) = if (i < h.size) h[i].toInt() and 0xFF else -1
        return when {
            at(0) == 0x50 && at(1) == 0x4B -> extractZip(root, base, bin, log)
            at(0) == 0xFD && at(1) == 0x37 && at(2) == 0x7A && at(3) == 0x58 ->
                extractCompressed(root, base, XZCompressorInputStream(bin), name, log)
            at(0) == 0x1F && at(1) == 0x8B -> extractCompressed(root, base, GzipCompressorInputStream(bin), name, log)
            at(0) == 0x42 && at(1) == 0x5A && at(2) == 0x68 -> extractCompressed(root, base, BZip2CompressorInputStream(bin), name, log)
            isTar(h) -> extractTar(root, base, bin, log)
            else -> throw IllegalArgumentException("Unsupported archive. Use zip, tar.xz, tar.gz, tar.bz2 or tar.")
        }
    }

    private val nestedExt = listOf(".tar.xz", ".txz", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2", ".tar", ".zip")

    /** Unpacks archives found inside the extracted files, each into a folder named after the archive. */
    private fun unpackNested(root: File, log: (String) -> Unit): Int {
        var total = 0
        repeat(3) {
            val archives = root.walkTopDown()
                .filter { f -> f.isFile && nestedExt.any { f.name.lowercase().endsWith(it) } }.toList()
            if (archives.isEmpty()) return total
            for (a in archives) {
                val folder = File(a.parentFile ?: root, a.name.substringBefore('.'))
                try {
                    log("Unpacking ${a.name}")
                    folder.mkdirs()
                    total += a.inputStream().use { extractAny(root, folder, it, a.name, log) }
                    a.delete()
                } catch (e: Exception) {
                    log("Skipped ${a.name}: ${e.message}")
                    a.renameTo(File(a.path + ".failed"))
                }
            }
        }
        return total
    }

    /** Extracts zip / tar.xz / tar.gz / tar.bz2 / tar (detected by content) plus any archives inside it. Returns file count. */
    fun extractArchive(ctx: Context, input: InputStream, name: String, log: (String) -> Unit = {}): Int {
        val root = dir(ctx).canonicalFile
        val n = extractAny(root, root, input, name, log) + unpackNested(root, log)
        if (n == 0) throw IllegalArgumentException("The archive is empty")
        return n
    }

    fun importArchive(ctx: Context, uri: Uri, name: String, log: (String) -> Unit = {}): Int =
        ctx.contentResolver.openInputStream(uri)!!.use { extractArchive(ctx, it, name, log) }

    fun importFile(ctx: Context, uri: Uri, displayName: String) {
        val out = File(dir(ctx), displayName.substringAfterLast('/'))
        ctx.contentResolver.openInputStream(uri)!!.use { i -> out.outputStream().use { i.copyTo(it) } }
        finish(out)
    }

    private fun looksLikeArchive(f: File): Boolean = f.inputStream().use { s ->
        val a = s.read(); val b = s.read(); val c = s.read()
        (a == 0x50 && b == 0x4B) || (a == 0xFD && b == 0x37 && c == 0x7A) || (a == 0x1F && b == 0x8B) || (a == 0x42 && b == 0x5A && c == 0x68)
    }

    /** Downloads url. Archives are extracted, anything else is saved as a single file. onProgress gets 0..1 (or -1 if unknown). */
    fun download(ctx: Context, url: String, onProgress: (Float) -> Unit): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000; readTimeout = 30000; instanceFollowRedirects = true
        }
        try {
            if (conn.responseCode !in 200..299) throw java.io.IOException("Server returned HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong
            val tmp = File(ctx.cacheDir, "qemu_download.tmp")
            conn.inputStream.use { i -> tmp.outputStream().use { o ->
                val buf = ByteArray(64 * 1024); var done = 0L
                while (true) {
                    val n = i.read(buf); if (n < 0) break
                    o.write(buf, 0, n); done += n
                    onProgress(if (total > 0) done.toFloat() / total else -1f)
                }
            } }
            val name = url.substringBefore('?').substringAfterLast('/').ifBlank { "qemu-binary" }
            val msg = if (looksLikeArchive(tmp)) {
                val n = tmp.inputStream().use { extractArchive(ctx, it, name) }; "Installed $n files"
            } else {
                val out = File(dir(ctx), name); tmp.copyTo(out, overwrite = true); finish(out); "Saved $name"
            }
            tmp.delete()
            return msg
        } finally { conn.disconnect() }
    }
}
