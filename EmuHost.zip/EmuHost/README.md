# EmuHost – Material You front-end for QEMU on Android

Kotlin + Jetpack Compose + Material 3 (dynamic color on Android 12+).

## What's included
- VM list, create-VM wizard (Android 4.4–10 x86 guests, or PC OS from .img/.iso/.qcow2)
- RAM / cores / arch / KVM options, foreground service, QEMU command builder

## What you must add
1. Cross-compiled aarch64-android QEMU binaries (Termux's qemu or your own NDK build), renamed:
   libqemu-system-x86_64.so, libqemu-system-i386.so, libqemu-system-aarch64.so, libqemu-img.so
   -> app/src/main/jniLibs/arm64-v8a/ (or just use the in-app setup screen)
2. BIOS files (bios-256k.bin, vgabios-stdvga.bin, efi-virtio.rom, ...) -> assets, then copy to filesDir/bios on first launch.
3. A VNC viewer screen (next step): connect to 127.0.0.1:<vncPort>, or launch an external one like bVNC.

## Guest images
Android-x86 (up to 9.0 official), Bliss OS / Android-Generic (Android 10+ x86), any Linux/Windows ISO or disk image.
